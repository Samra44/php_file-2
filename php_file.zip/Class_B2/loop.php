<?php
// for ($i=0; $i<=10; $i++){
//     echo $i . "<br>";
// }
// for ($i=0; $i>=0; $i--){
//     if($i%2==0)
//     echo $i . "<br>";
// }
// for ($i=10; $i<=0; $i--){
//     if($i % 2 !== 0)
//     echo $i . "<br>";
// }

// for ($i =1; $i<=10;$i++){
//     if($i=5){
//     continue;
//     }
//     echo $i . "<br>";
// }

// for ($i =1; $i<=10;$i++){
//     if($i==4){
//     break;
//     }
//     echo $i . "<br>";
// }

$i = 0;
do{
  echo $i ."<br>";
  $i++;
}while($i=<10);


?>