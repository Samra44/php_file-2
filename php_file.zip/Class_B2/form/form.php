<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Php</title>
</head>
<body>
       <form action="test.php" method = "post">
       Name: <input type="text" name =  "name" ><b></b>
       Password: <input type="password" name =  "password" ><b></b>
       Email: <input type="email" name =  "email" ><b></b>
       Mobile: <input type="number" name=  "number" ><b></b>

       Gender: <input type="radio" name="gender" value = "male">male
       <input type="radio" name="gender" value = "female">female
       <input type="radio" name="gender" value = "other">other<br><b>
       <input type="submit" value = "submit">
       </form>

       
</body>
</html>