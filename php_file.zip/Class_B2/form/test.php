<?php

echo $_GET["name"];

echo "<pre>";
print_r ($_GET);
echo "</pre>";


// echo $_POST["name"];

// echo "<pre>";
// print_r ($_POST);
// echo "</pre>";




// echo $_POST["name"];

// echo "<pre>";
// print_r ($_REQUEST);
// echo "</pre>";



echo $_REQUEST ["email"]

// if($_REQUEST["name"] || $_REQUEST["email"])

// {
//     echo "welcome". $_REQUEST["name"]."<br>";
//     echo "welcome". $_REQUEST["email"]."<br>";
//     exist();
// }

if($_REQUEST["name"] === "Samra" || $_REQUEST["password"] ====12345){
    echo "Login Successfully";
}else{
    echo "Invalid User or password name";
}




?>