<form action="" method="post"><br><br>
User_name:<input type="text" name =  "username" ><b></b>
Password: <input type="password" name="password"><b></b>
Email: <input type="email" name="email"><b></b>>

submit: <input type="submit" name="save">
</form>

<?php
if(isset($_POST["save"])){
$username= $_POST["username"];
$password = $_POST ["password"];
$email= $_POST ["email"];
}

$con=mysql_connect("localhost","root","samrah");
if(!$con){
    echo "connect successfully";
}

$q= "INSERT INTO `samrah`(`username`, `password`, `email`) VALUES ('$username','$password','$email')";
$run=mysql_query($con,$q);
if($run){
    "<script>alert('connection sucessfully built')</script>";
}else{
    "<script>alert('failed')</script>";

}

?>