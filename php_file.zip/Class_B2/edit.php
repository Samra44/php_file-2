<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit.php</title>
</head>
<body>
    <?php
    $conn = mysqli_connect("localhost", "root","a_shop");
    $id = $_GET['id'];
    $sql = "SELECT * From user WHERE id = '{$id}'";
    $run = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($run)
    ?>
   <form action="update.php" meethod="post">
   <input type="hidden" name= "id" values = "<?php echo $row ['id']?>"><b></b>
   <input type="text" name= "username"  id="" values = "<?php echo $row ['Username'];?>"><b></b>
   <input type="email" name= "email"  id="" values = "<?php echo $row ['email'];?>"><b></b>
   <input type="text" name= "address"  id="" values = "<?php echo $row ['Address'];?>"><b></b>
   <input type="text" name= "phone"  id="" values = "<?php echo $row ['PhoneNo'];?>"><b></b>
   <input type="submit" name= "update"  values = "Update" name= "updatebtn">
   </form>


</body>
</html>